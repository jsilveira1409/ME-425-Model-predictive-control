addpath(fullfile('..', 'src'));

%% TODO: This file should produce all the plots for the deliverable